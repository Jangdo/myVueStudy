import { useEffect, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import './styles.css'

const GURO_DIGITAL = { lat: 37.4853, lng: 126.8958 }
const places = [
  { id: 1, name: '디지털 한상', distance: '도보 3분', time: '11:30 - 13:30', position: { lat: 37.48483, lng: 126.89676 }, menu: '제육볶음 정식', price: '7,500원', img: 'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=900&q=85', tags: ['매콤', '인기'], color: '#ff6847' },
  { id: 2, name: '에이스 푸드홀', distance: '도보 6분', time: '11:20 - 13:40', position: { lat: 37.48618, lng: 126.89745 }, menu: '닭갈비 & 볶음밥', price: '8,000원', img: 'https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=900&q=85', tags: ['든든', '셀프바'], color: '#5d75ed' },
  { id: 3, name: '구로 타워 키친', distance: '도보 8분', time: '11:30 - 14:00', position: { lat: 37.48376, lng: 126.89437 }, menu: '버섯 불고기 덮밥', price: '7,800원', img: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=900&q=85', tags: ['건강식', '혼밥'], color: '#29a98c' },
  { id: 4, name: '스마트 밥상', distance: '도보 10분', time: '11:30 - 13:30', position: { lat: 37.4839, lng: 126.89846 }, menu: '오늘의 비빔밥', price: '7,000원', img: 'https://images.unsplash.com/photo-1498654896293-37aacf113fd9?auto=format&fit=crop&w=900&q=85', tags: ['가성비'], color: '#f3b63b' }
]

function loadGoogleMaps(apiKey) {
  if (window.google?.maps) return Promise.resolve(window.google.maps)
  return new Promise((resolve, reject) => {
    const script = document.createElement('script')
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&v=weekly&libraries=marker`
    script.async = true
    script.onload = () => resolve(window.google.maps)
    script.onerror = () => reject(new Error('Google Maps를 불러오지 못했습니다.'))
    document.head.appendChild(script)
  })
}

function infoContent(place) {
  const content = document.createElement('article')
  content.className = 'map-bubble'
  content.innerHTML = `<img src="${place.img}" alt="${place.menu} 식판"><div class="bubble-copy"><span>${place.name} · ${place.distance}</span><strong>${place.menu}</strong><small>${place.price} · 오늘 운영중</small></div>`
  return content
}

function GoogleMap({ selected, onSelect }) {
  const mapRef = useRef(null)
  const [status, setStatus] = useState('loading')
  const selectedRef = useRef(selected)
  const mapStore = useRef({ map: null, info: null, markers: new Map() })
  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY

  useEffect(() => { selectedRef.current = selected }, [selected])
  useEffect(() => {
    if (!apiKey) { setStatus('missing-key'); return }
    let alive = true
    loadGoogleMaps(apiKey).then(async (maps) => {
      if (!alive) return
      const map = new maps.Map(mapRef.current, {
        center: GURO_DIGITAL, zoom: 16.4, disableDefaultUI: true, zoomControl: true, gestureHandling: 'greedy',
        styles: [
          { featureType: 'poi', stylers: [{ visibility: 'off' }] },
          { featureType: 'transit', stylers: [{ visibility: 'off' }] },
          { featureType: 'road', elementType: 'labels.icon', stylers: [{ visibility: 'off' }] }
        ]
      })
      const info = new maps.InfoWindow({ pixelOffset: new maps.Size(0, -6), disableAutoPan: true })
      mapStore.current = { map, info, markers: new Map() }
      places.forEach(place => {
        const marker = new maps.Marker({ map, position: place.position, title: place.name, label: { text: '🍴', fontSize: '14px' }, icon: { path: maps.SymbolPath.CIRCLE, fillColor: place.color, fillOpacity: 1, strokeColor: '#ffffff', strokeWeight: 3, scale: 15 } })
        marker.addListener('click', () => onSelect(place))
        mapStore.current.markers.set(place.id, marker)
      })
      setStatus('ready')
    }).catch(() => alive && setStatus('error'))
    return () => { alive = false }
  }, [apiKey, onSelect])

  useEffect(() => {
    const { map, info, markers } = mapStore.current
    if (!map || !info) return
    const marker = markers.get(selected.id)
    if (!marker) return
    info.setContent(infoContent(selected))
    info.open({ map, anchor: marker, shouldFocus: false })
  }, [selected, status])

  return <div className="map-wrap"><div ref={mapRef} className="google-map" />
    {status !== 'ready' && <div className="map-state"><span>⌖</span><strong>{status === 'loading' ? '구로디지털단지 지도를 불러오는 중' : status === 'missing-key' ? '구글 지도 API 키가 필요해요' : '지도를 불러오지 못했어요'}</strong>{status === 'missing-key' && <small>.env 파일에 VITE_GOOGLE_MAPS_API_KEY를 추가해 주세요.</small>}</div>}
    <div className="map-title"><p>서울 구로구</p><strong>구로디지털단지</strong></div><div className="map-hint">식당 핀을 터치해<br />오늘 메뉴를 확인하세요</div>
  </div>
}

function App() {
  const [selected, setSelected] = useState(places[0])
  const [filter, setFilter] = useState('전체')
  const shown = filter === '전체' ? places : places.filter(place => place.tags.includes(filter))
  return <main className="mobile-app">
    <header className="app-header"><div className="brand"><span>⌁</span>오늘의 식판</div><button aria-label="알림">♧</button></header>
    <GoogleMap selected={selected} onSelect={setSelected} />
    <section className="bottom-sheet"><div className="handle" /><div className="sheet-heading"><div><p>2026. 07. 15 · 수요일</p><h1>오늘 뭐 먹지?</h1></div><button aria-label="날짜 선택">▦</button></div>
      <div className="filters">{['전체', '인기', '매콤', '건강식', '가성비'].map(item => <button key={item} className={filter === item ? 'active' : ''} onClick={() => setFilter(item)}>{item}</button>)}</div>
      <div className="nearby-title"><span>내 주변 구내식당</span><b>{shown.length}곳</b></div>
      <div className="place-list">{shown.map(place => <button key={place.id} className={selected.id === place.id ? 'selected' : ''} onClick={() => setSelected(place)}><img src={place.img} alt="" /><span><strong>{place.name}</strong><small>{place.distance} · {place.menu}</small></span><em>›</em></button>)}</div>
    </section>
  </main>
}

createRoot(document.getElementById('root')).render(<App />)
